firstnumber = 9    # Declaring and initializing the first variable 
secondnumber = 5   # Declaring and initializing the second variable

# Performing addition
sumofnumbers = firstnumber + secondnumber  

# Performing subtraction
difference = secondnumber - firstnumber  

# Printing the results with descriptive messages
print("Sum:", sumofnumbers)           
print("Difference:", difference)