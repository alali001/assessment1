# Assigning strings to variables
word1 = "Coding"
word2 = "is"
word3 = "Cool"

# Concatenating strings using f-string and printing the result
print(f"{word1} {word2} {word3}")